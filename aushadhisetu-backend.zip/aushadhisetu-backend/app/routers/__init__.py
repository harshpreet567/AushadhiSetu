"""
AushadhiSetu Router Endpoints
"""
